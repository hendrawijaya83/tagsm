<?php
// pengecekan ajax request untuk mencegah direct access file, agar file tidak bisa diakses secara langsung dari browser
// jika ada ajax request
//if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') && (isset($_POST['startDate']) && isset($_POST['endDate']))) {
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) {
    // nama tabel
    //$table = 'tblprod a inner join tblcat b on a.fk_catid=b.catid';
    $table = 'vwtblsi';
    // primary key tabel
    $primaryKey = 'siid';

    // membuat array untuk menampilkan isi tabel.
    // Parameter 'db' mewakili nama kolom dalam database.
    // parameter 'dt' mewakili pengenal kolom pada DataTable.
    $columns = array(
        array( 'db' => 'siid', 'dt' => 1 ),
        array( 'db' => 'custname', 'dt' => 2 ),
        array( 'db' => 'sidate', 'dt' => 3, 'formatter' => function ($d, $row) {
                return date('d-m-Y', strtotime($d));
            }),
        array( 'db' => 'total2', 'dt' => 4 ),
        array( 'db' => 'payamtondate', 'dt' => 5 ),
        array( 'db' => 'sibalance', 'dt' => 6 ),
        array( 'db' => 'printeddate', 'dt' => 7 ),
        /*array(
            'db' => 'tanggal_daftar',
            'dt' => 5,
            'formatter' => function ($d, $row) {
                return date('d-m-Y', strtotime($d));
            }
        ),*/
    );
//echo "berhasil";
    // memanggil file "database.php" untuk informasi koneksi ke server SQL
    require_once "config/database.php";
    // memanggil file "ssp.class.php" untuk menjalankan datatables server-side processing
    require 'config/ssp.class.php';
    //$date1=$_POST['startDate'];
    //$date2=$_POST['endDate'];
    $date1=$_GET['startDate'];
    $date2=$_GET['endDate'];
    //$date1="2024-01-02";
    //$date2="2024-01-04";
    //$siid=$_GET['siid'];
    //$siid=$_POST["siid"];
    //$where = " month(sidate)=1 and year(sidate)=2024";
    $where = " sidate between '{$date1}' and '{$date2}'";
    //$where = " sidate between '" .$date1."' and '". $date2."'";
    //$where = " sidate = '" .$date1."'";
    //echo $date1;
    //$where=" siid=105105";
    //$where=" siid=".$siid;
    echo json_encode(
        SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns,$whereResult = null, $where )
    );
}
// jika tidak ada ajax request
else {
    // alihkan ke halaman index
    session_start();
    session_destroy();
    header('location: index.php');
}
