<?php
// pengecekan ajax request untuk mencegah direct access file, agar file tidak bisa diakses secara langsung dari browser
// jika ada ajax request
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) {
    /* if (!defined('SECURE_ACCESS')) {
        die('Direct access not permitted');
    } */

session_start();

//include('koneksi.php');
require_once "config/config.php";

$username     = $_POST['username'];
//$password      = MD5($_POST['password']);
$password      = $_POST['password'];

//query
$query  = "SELECT userid,loginandroid FROM tbluser WHERE userid='$username' AND password='$password'";
$result     = mysqli_query($mysqli, $query);
$num_row     = mysqli_num_rows($result);
$row         = mysqli_fetch_array($result);

if($num_row >=1) {
    
    //echo "success";

    $_SESSION['id_user']       = $row['userid'];
    //$_SESSION['loginandroid']       = true;
    //define('loginonline', true);
    //$_SESSION['loginandroid']       = $row['loginandroid'];
    //$_SESSION['nama_lengkap'] = $row['nama_lengkap'];
    //$_SESSION['username']       = $row['username'];
    echo json_encode(array("pesan" => "success", "userid" => $row['userid'], "loginandroid" => $row['loginandroid']));
} else {
    //define('loginonline', false);
    //echo "error";
    echo json_encode(array("pesan" => "error","userid" => "", "loginandroid" => "0"));
}
}
