<?php
if (!defined('SECURE_ACCESS')) {
  die('Direct access not permitted');
}

?>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script> -->
<!-- <script src="https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx-js-style.min.js"></script>  -->
<!-- <script type="text/javascript"> -->
<script>
    function exportToPDF(strTitle,strfile) {
      showLoading();
      
      // Use setTimeout to allow UI to update before heavy processing
      setTimeout(() => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Add title
        doc.setFontSize(14);
        doc.text(strTitle,  5, 10);
        //doc.setFontSize(11);
        //doc.text(`Generated on ${new Date().toLocaleDateString()}`, 14, 22);
        
        // Export table to PDF
        doc.autoTable({
          html: '#data-table',
          startY: 12,
          headStyles: {
            fillColor: [41, 128, 185],
            textColor: 255,
            fontSize: 9,
            halign: 'center',
          },
          bodyStyles: {
            fontSize: 7
          },
          styles: {
            cellPadding: 1,
            overflow: 'pagebreak'
          },
          columnStyles: {
            0: { cellWidth: 8, halign: 'right'}, // Record number column
            2: { cellWidth: 15, halign:'center' }, // Item column
            3: { cellWidth: 15, halign: 'right'},
            4: { cellWidth: 25, halign: 'right'},
            5: { cellWidth: 15, halign: 'right'},
            6: { cellWidth: 25, halign: 'right'},
            7: { cellWidth: 40 },
            8: { cellWidth: 20, halign: 'center' } // Salary column
          },
          margin: { top: 5, bottom: 5, left: 2, right: 2},
          didDrawPage: function(data) {
            // Footer with page numbers
            doc.setFontSize(8);
            const pageCount = doc.internal.getNumberOfPages();
            doc.text(
              `Page ${data.pageNumber} of ${pageCount}`,
              data.settings.margin.left,
              doc.internal.pageSize.height - 3
            );
          }
        });
        
        // Save the PDF
        var today = new Date();
        var datePdf = today.getFullYear() + '-' + 
                                (today.getMonth()+1) + '-' + 
                                today.getDate() + '_' + 
                                today.getHours() + '-' + 
                                today.getMinutes() + '-' + 
                                today.getSeconds();        
        doc.save(strfile + datePdf + '.pdf');

        hideLoading();
      }, 100);
    }

  function exportToPDF2(strfile) {
      showLoading();
      setTimeout(() => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('p', 'pt', 'a4');
        const columns = [
          { header: 'No', dataKey: 'no' },
          { header: 'Item', dataKey: 'item' },
          { header: 'Exp Date', dataKey: 'expDate' },
          { header: 'Saldo', dataKey: 'saldo' },
          { header: 'Harga @', dataKey: 'hargaAt' },
          { header: '% Modal', dataKey: 'psnModal' },
          { header: 'Saldo Rp.', dataKey: 'saldoRp' },
          { header: 'Harga Jual', dataKey: 'hargaJual' },
          { header: 'Batch ID', dataKey: 'batchId' }
        ];

        const rows = filterData.map((item, index) => ({
          no: index + 1,
          item: item.ProdDescription,
          expDate: formatDate(item.expdate),
          saldo: formatter.format(item.saldo2),
          hargaAt: formatter.format(item.SupPrice),
          psnModal: formatter.format(item.psnmodal),
          saldoRp: formatter.format(item.saldopo),
          hargaJual: item.hargajual,
          batchId: item.batchid
        }));

        doc.autoTable({
          head: [columns.map(col => col.header)],
          body: rows.map(row => columns.map(col => row[col.dataKey])),
          styles: {
            fontSize: 10,
            cellPadding: 3,
            halign: 'center',
            valign: 'middle'
          },
          headStyles: {
            fillColor: '#f2f2f2',
            textColor: '#000',
            fontStyle: 'bold'
          }
        });

        //doc.save('exportHistory.pdf');
        // Save the PDF
        var today = new Date();
        var datePdf = today.getFullYear() + '-' + 
                                (today.getMonth()+1) + '-' + 
                                today.getDate() + '_' + 
                                today.getHours() + '-' + 
                                today.getMinutes() + '-' + 
                                today.getSeconds();        
        doc.save(strfile + datePdf + '.pdf');

        hideLoading();
      }, 1000);
    }

  function exportToExcel2(strTitle, strfile) {
      showLoading();
      
      setTimeout(() => {        
        const data=filterData;

        const ws = XLSX.utils.json_to_sheet(data.map(item => ({
        //'No': index + 1,
        'Item': item.ProdDescription, 
        'Exp Date': item.expdate,
        'Saldo': item.saldo2,
        'Harga@': item.SupPrice,
        '% Modal': item.psnmodal,
        'Saldo Rp.': item.saldopo,
        'Harga Jual': item.hargajual,
        'Batch ID': item.batchid
        })));

        // Create worksheet
        //const ws = XLSX.utils.aoa_to_sheet(data);
        
        // Create workbook
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, strTitle);
        
        // Set column widths
        ws['!cols'] = [
          //{ wch: 8 }, 
          { wch: 35 }, 
          { wch: 15 }, 
          { wch: 15 }, 
          { wch: 25 }, 
          { wch: 15 }, 
          { wch: 25 }, 
          { wch: 40 },
          { wch: 20}  
        ];        

// Format headers
      const headerRange = XLSX.utils.decode_range(ws['!ref']);
      for (let col = headerRange.s.c; col <= headerRange.e.c; col++) {
        const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
        if (!ws[cellAddress]) continue;
        
        ws[cellAddress].s = {
          font: { bold: true },
          //fill: { fgColor: { rgb: "D3D3D3" } },
          alignment: { horizontal: "center" }
        };
      }
      // Format salary column as currency
      // for (let row = 1; row <= data.length; row++) {
      //   cellAddress1 = XLSX.utils.encode_cell({ r: row, c: 4 }); // Salary column (0-based index 4)
      //   if (ws[cellAddress1]) {
      //     ws[cellAddress1].z = '#,##0.00';
      //   }
      //   const cellAddress2 = XLSX.utils.encode_cell({ r: row, c: 6 }); // Salary column (0-based index 4)
      //   if (ws[cellAddress2]) {
      //     ws[cellAddress2].z = '#,##0.00';
      //   }
      // }

      ws['!frozen'] = { xSplit: 0, ySplit: 1 };
      
      // Add auto-filter
      ws['!autofilter'] = { 
        ref: XLSX.utils.encode_range({
          s: { r: 0, c: 0 },
          e: { r: data.length, c: headerRange.e.c }
        })
      };

        var today = new Date();
        var dateExcel = today.getFullYear() + '-' + 
                                  (today.getMonth()+1) + '-' + 
                                  today.getDate() + '_' + 
                                  today.getHours() + '-' + 
                                  today.getMinutes() + '-' + 
                                  today.getSeconds();  
        XLSX.writeFile(wb, strfile + dateExcel + '.xlsx');

        hideLoading();
      }, 100);
    }
function exportToExcel3(strTitle, strfile) {
      showLoading();
      setTimeout(() => {
        const wb = XLSX.utils.book_new();
        const wsData = [];
        const headers = [
          'No', 'Item', 'Exp Date', 'Saldo', 'Harga @', '% Modal', 'Saldo Rp.', 'Harga Jual', 'Batch ID'
        ];
        wsData.push(headers);

        filterData.forEach((item, index) => {
          wsData.push([
            index + 1,
            item.ProdDescription,
            formatDate(item.expdate),
            formatter.format(item.saldo2),
            formatter.format(item.SupPrice),
            formatter.format(item.psnmodal),
            formatter.format(item.saldopo),
            item.hargajual,
            item.batchid
          ]);
        });

        const ws = XLSX.utils.aoa_to_sheet(wsData);
        // Set column widths and styles
        ws['!cols'] = [
          { wch: 5 }, // No
          { wch: 30 }, // Item
          { wch: 15 }, // Exp Date
          { wch: 10, z: '#,##0.00' }, // Saldo
          { wch: 10, z: '#,##0.00' }, // Harga @
          { wch: 10, z: '#,##0.00' }, // % Modal
          { wch: 10, z: '#,##0.00' }, // Saldo Rp.
          { wch: 15 }, // Harga Jual
          { wch: 15 } // Batch ID
        ];

        // Add styles to the header row
        for (let i = 0; i < headers.length; i++) {
          const cellAddress = XLSX.utils.encode_cell({ r: 0, c: i });
          ws[cellAddress].s = {
            font: { bold: true },
            fill: { fgColor: { rgb: "FFFF00" } } // Yellow background for header
          };
        }

        // // const wbName = `saldoitembatch ${new Date().toISOString().slice(0, 10)}.xlsx`;
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        // XLSX.writeFile(wb, wbName);
        var today = new Date();
        var dateExcel = today.getFullYear() + '-' + 
                                  (today.getMonth()+1) + '-' + 
                                  today.getDate() + '_' + 
                                  today.getHours() + '-' + 
                                  today.getMinutes() + '-' + 
                                  today.getSeconds();  
        XLSX.writeFile(wb, strfile + dateExcel + '.xlsx');
        
        hideLoading();
      }, 1000);
    }

async function exportWithTemplate(data2,strfile) {
    // 1. Fetch your template file
    const templateUrl = strfile+'.xlsx';
    const templateResponse = await fetch(templateUrl);
    const templateArrayBuffer = await templateResponse.arrayBuffer();
    
    // 2. Read the template workbook
    const templateWB = XLSX.read(templateArrayBuffer);
    const ws = templateWB.Sheets[templateWB.SheetNames[0]]; // Get first sheet
    
    // 3. Prepare your data (example array of objects)
    const data=data2;
    
    // 4. Find where to insert data (e.g., starting at A2)
    const startCell = "A2";
    
    // 5. Convert data to worksheet format
    const newData = XLSX.utils.json_to_sheet(data, { skipHeader: false });
    
    // 6. Merge data into template
    const range = XLSX.utils.decode_range(newData['!ref']);
    for(let R = range.s.r; R <= range.e.r; ++R) {
        for(let C = range.s.c; C <= range.e.c; ++C) {
            const cellAddress = XLSX.utils.encode_cell({r:R, c:C});
            const templateAddress = XLSX.utils.encode_cell({
                r: R + XLSX.utils.decode_cell(startCell).r,
                c: C + XLSX.utils.decode_cell(startCell).c
            });
            
            if(newData[cellAddress]) {
                ws[templateAddress] = newData[cellAddress];
            }
        }
    }
    
    // 7. Update the worksheet range
    const wsRange = XLSX.utils.decode_range(ws['!ref']);
    const newRange = XLSX.utils.decode_range(newData['!ref']);
    ws['!ref'] = XLSX.utils.encode_range({
        s: wsRange.s,
        e: {
            r: Math.max(wsRange.e.r, newRange.e.r + XLSX.utils.decode_cell(startCell).r),
            c: Math.max(wsRange.e.c, newRange.e.c + XLSX.utils.decode_cell(startCell).c)
        }
    });
    
    // 8. Export the populated template
    XLSX.writeFile(templateWB, "export_with_template.xlsx");
}    


function exportToExcel(jsonData, fileName = 'products.xls') {
  // Create HTML table with styles
  const html = `
  <html xmlns:o="urn:schemas-microsoft-com:office:office" 
        xmlns:x="urn:schemas-microsoft-com:office:excel">
  <head>
    <!--[if gte mso 9]>
    <xml>
      <x:ExcelWorkbook>
        <x:ExcelWorksheets>
          <x:ExcelWorksheet>
            <x:Name>Sheet1</x:Name>
            <x:WorksheetOptions>
              <x:DisplayGridlines/>
              <x:freezePanes/>
              <x:FrozenNoSplit/>
              <x:SplitHorizontal>1</x:SplitHorizontal>
              <x:TopRowBottomPane>1</x:TopRowBottomPane>
            </x:WorksheetOptions>
          </x:ExcelWorksheet>
        </x:ExcelWorksheets>
      </x:ExcelWorkbook>
    </xml>
    <![endif]-->
    <style>
      .excel-table {
        border-collapse: collapse;
        width: 100%;
      }
      .excel-table th {
        background-color: #4472C4;
        color: white;
        font-weight: bold;
        text-align: center;
        padding: 8px;
        border: 1px solid #5F5F5F;
      }
      .excel-table td {
        padding: 5px;
        border: 1px solid #A5A5A5;
      }
      .excel-table tr:nth-child(even) {
        background-color: #E9E9E9;
      }
      .number {
        text-align: right;
      }
      .number2 {
        text-align: right;
        mso-number-format:"#,##0.00"; /*format number*/
      }
      .date {
        text-align: center;
        mso-number-format:"dd-Mmm-yyyy"; /*format date*/
      }
      .textleft {
        mso-number-format:"\@";/*force text*/
      }
      .textcenter {
        text-align: center;
        mso-number-format:"\@"; /*force text*/}
    </style>
  </head>
  <body>
    <table class="excel-table">
      <thead>
      <tr>
        <th>No</th>
        <th>Mesin</th>
        <th><span>Item</span>
        </th>
        <th>Target</th>
        <th>Selesai</th>
        <th>Deadline</th>
        <th>Status</th>
        <th>Konsumen</th>
        <th>Q</th>
        <th>Plan ID</th>            
      </tr>
      </thead>
      <tbody>
        ${jsonData.length === 0 ? '' : jsonData.map((item, index) => `
          <tr>
              ${item.map((value,index) => `
                <td class="${(index == 2 || index == 7) ? 'textleft' : 
                (index == 5 ? 'date' : 
                ((index==3 || index == 4 || index == 8 || index == 9) ?
                 'number2' : 
                 (index == 1 || index == 6) ? 'textcenter' : 'number'))}">                                  
                  ${value}
                </td>
              `).join('')}
          </tr>
        `).join('')}
      </tbody>
    </table>
  </body>
  </html>`;
//            ${Object.keys(jsonData[0]).map(key => `<th>${key}</th>`).join('')}

  // Create blob and download
  const blob = new Blob([html], {type: 'application/vnd.ms-excel'});
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Example usage:
</script>