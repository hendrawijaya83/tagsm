<?php
// pengecekan ajax request untuk mencegah direct access file, agar file tidak bisa diakses secara langsung dari browser
// jika ada ajax request
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) {
    // nama tabel
    //$table = 'tblprod a inner join tblcat b on a.fk_catid=b.catid';
    $table = 'vwtblmsnplanitem';
    // primary key tabel
    $primaryKey = 'mesin';

    // membuat array untuk menampilkan isi tabel.
    // Parameter 'db' mewakili nama kolom dalam database.
    // parameter 'dt' mewakili pengenal kolom pada DataTable.
    $columns = array(
        array( 'db' => 'mesin', 'dt' => 1 ),
        array( 'db' => 'sisa', 'dt' => 2 ),
        array( 'db' => 'target', 'dt' => 3 ),
        array( 'db' => 'kapmesin', 'dt' => 4 ),
        array( 'db' => 'adddate', 'dt' => 5 ),
        array( 'db' => 'nama', 'dt' => 6 ),
        array( 'db' => 'lebar', 'dt' => 7 ),
        array( 'db' => 'nextitem', 'dt' => 8 ),
        array( 'db' => 'nexttarget', 'dt' => 9 ),
        //array( 'db' => 'nextnoplan', 'dt' => 10 ),
        /*array(
            'db' => 'tanggal_daftar',
            'dt' => 5,
            'formatter' => function ($d, $row) {
                return date('d-m-Y', strtotime($d));
            }
        ),
        array( 'db' => 'kelas', 'dt' => 6 ),
        array( 'db' => 'id_siswa', 'dt' => 7 )*/
    );

    // memanggil file "database.php" untuk informasi koneksi ke server SQL
    require_once "config/database.php";
    // memanggil file "ssp.class.php" untuk menjalankan datatables server-side processing
    require 'config/ssp.class.php';

    echo json_encode(
        SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
    );
}
// jika tidak ada ajax request
else {
    // alihkan ke halaman index
    header('location: index.php');
}
