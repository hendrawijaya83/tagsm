<?php
// pengecekan ajax request untuk mencegah direct access file, agar file tidak bisa diakses secara langsung dari browser
// jika ada ajax request
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) {
    // panggil file "config.php" untuk koneksi ke database
    require_once "config/config.php";

    // mengecek data GET dari ajax
    if (isset($_GET['id_item'])) {
        // ambil data GET dari ajax
        $id_item = $_GET['id_item'];

        // sql statement untuk menampilkan data dari tabel "tbl_siswa" berdasarkan "id_siswa"
        $query = $mysqli->query("SELECT a.proddescription,a.prodid,a.saldo2,b.catid,a.nilaipo,case a.saldo2=0 then 0 else a.totalpo/a.saldo2 end as persenmod, a.karton,a.ket,a.srprice FROM tblprod a inner join tblcat b on a.fk_catid=b.catid WHERE a.prodid='$id_item'")
                                or die('Ada kesalahan pada query tampil data : ' . $mysqli->error);
        // ambil data hasil query
        $data = $query->fetch_assoc();

        // tampilkan data
        echo json_encode($data);
    }
}
// jika tidak ada ajax request
else {
    // alihkan ke halaman index
    header('location: index.php');
}
