
<?php
// panggil file "database.php" untuk koneksi ke database
require_once "config/database.php";
define('SECURE_ACCESS', true);

include 'auth.php';
?>

<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Aplikasi Tag SM">
    <!-- Csrf Token -->
    <meta name="csrf-token" content="<?= $_SESSION['csrf_token'] ?>">
    <!-- Title -->
    <title>Tag Master SM</title>

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="assets/css/datatables.bootstrap5.min.css"> -->
    <!-- <link rel="stylesheet" type="text/css" href=https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css> -->
    <link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.min.css">
    <!-- <link rel="stylesheet" type="text/css" href=https://cdn.datatables.net/searchpanes/2.1.1/css/searchPanes.dataTables.min.css>    -->
    <!-- jQuery Core -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <style>
        /* Create two equal columns that floats next to each other */
        @media (max-width:575.98px) {        
    }        
        @media (max-width:1399.98px) {        
    }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
        }
        .fixed-top2 {
            position: fixed;
            top: 0;
            right: 0;
            left: 0;
            z-index: 1029;
            background-color: #fd7e14;
        }
        /* .row {
            position:sticky;
            top:1px; left:0;
            bottom:10px;   right:0;
            overflow-y:scroll;
            overflow-x:hidden;
            z-index: 10;
        } */
         .thin-navbar {            
            min-height: 40px !important;
            padding-top: 0;
            padding-bottom: 0;
        }
        
        .thin-navbar .navbar-brand {
            padding-top: 0.25rem;
            padding-bottom: 0.25rem;
            font-size: 1.1rem;
        }
        
        .thin-navbar .nav-link {
            padding-top: 0.5rem;
            padding-bottom: 0.5rem;
        }
        
        .thin-navbar .navbar-toggler {
            padding: 0.25rem 0.5rem;
        }
        header {
            position: sticky;
            top: 0;
            z-index: 1020; /* Ensure it stays above other content */
            width: 100%;}
    </style>
</head>

<body class="d-flex flex-column h-80">
    <!-- Preloader -->
    <div style="display: none;" class="preloader">
        <div class="loading">
            <img src="assets/img/spinner-loading.gif" alt="Loading" width="200">
        </div>
    </div>

    <!-- Header -->
    <header>
        <!--Navbar -->
        <nav class="navbar navbar-expand-lg bg-primary shadow">
            <!--<div class="container-fluid px-lg-5"> -->
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span> MENU
                </button>
                <!-- <span class="navbar-brand text-black"> -->
                    <!-- <i class="fa-solid fa-laptop-code me-2"></i> -->
                    <a class="navbar-brand" href="#">
                    Tag Master SM - <?php
                        if (isset($_GET['kemenu'])) {
                            if (substr($_GET['kemenu'],0,5)=="trans") {
                                $_kemenu = $_GET['kemenu'];
                            } else {
                                $_kemenu = ucfirst($_GET['kemenu']);
                            }
                        } else {
                            $_kemenu = 'transimport tag';
                        }
                        if (substr($_kemenu,0,5)=="trans") {
                            $_kemenu2=strtoupper(substr($_kemenu, strpos($_kemenu,"s")+1));
                            echo "Data $_kemenu2"  ;
                        } else {
                            echo "Master $_kemenu";
                        }
                        ?>
                    </a>
                <!-- </span> -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                        <li class="nav-item dropdown">
                            <a class="nav-link disabled dropdown-toggle text-white" href="#" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Master
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="?kemenu=item" target="_self">Item</a></li>
                                <!-- <li><a class="dropdown-item" href="?kemenu=itembatch">Item Batch</a></li> -->
                                <li><a class="dropdown-item" href="?kemenu=mesin">Mesin</a></li>
                                <li><a class="dropdown-item" href="?kemenu=plan">Plan</a></li>
                                <!-- <li>
                                    <hr class="dropdown-divider">
                                </li> -->
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link disabled dropdown-toggle text-white" href="#" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Transaksi
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item disabled" href="?kemenu=transspp">SPP</a></li>
                                <li><a class="dropdown-item disabled" href="?kemenu=transtagblowing">Tag Blowing</a></li>
                                <li><a class="dropdown-item" href="?kemenu=transtag beli">Tag Pembelian</a></li>
                                <!--<li><a class="dropdown-item" href="#">Another action</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>-->
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Import
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="?kemenu=transimport tag">Tag</a></li>
                                <!-- <li><a class="dropdown-item disabled" href="?kemenu=transtagblowing">Tag Blowing</a></li>
                                <li><a class="dropdown-item" href="?kemenu=transtag beli">Tag Pembelian</a></li> -->
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" aria-disabled="true">Report</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link text-white" href="logout.php">Logout</a>
                        </li> -->
                    </ul>
                        <div class="d-flex align-items-center">
                            <span class="text-white me-3 small">Welcome,                         
                                <?php
                                    //session_start();
                                    echo $_SESSION['id_user'];
                                    //echo "a";
                                ?></span>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4Zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10Z"/>
                                    </svg>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <!-- <li><a class="dropdown-item" href="#">Profile</a></li>
                                    <li><a class="dropdown-item" href="#">Settings</a></li>
                                    <li><hr class="dropdown-divider"></li> -->
                                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="flex-shrink-1">
        <div class="container-fluid pt-2 px-lg-2 mt-lg-1">

            <?php
            //include "view.php";
            
            if (isset($_GET['kemenu'])) {
                $_kemenu = $_GET['kemenu'];
            } else {
                $_kemenu = 'transimport tag';
            }
            //echo $_kemenu;    
            if ($_kemenu == 'item') {
                include "view.php";
            } elseif ($_kemenu == 'mesin') {
                include "viewmesin.php";
            } elseif ($_kemenu == 'plan') {
                include "viewplan4.php";
            } elseif ($_kemenu == 'transspp') {
                include "viewspp.php";
            } elseif ($_kemenu == 'transtagblowing') {
                include "viewtagblowing.php";}
            elseif ($_kemenu == 'transtag beli') {
                include "view/vwtagimport.php";}
            elseif ($_kemenu == 'transimport tag') {
                include "view/vwtagimport.php";}
            ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer mt-auto bg-white shadow py-2">
        <div class="container-fluid px-lg-2">
            <!-- copyright -->
            <div class="copyright text-center mb-1 mb-md-0">
                &copy; 2024 - <a href="#" target="_blank" class="text-brand text-decoration-none">HW</a> <small id="maxwidth"></small>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>

    <script type="text/javascript">
        (function ($) {
            $.fn.getDate = function (format) {

                var gDate = new Date();
                var mDate = {
                    'S': gDate.getSeconds(),
                    'M': gDate.getMinutes(),
                    'H': gDate.getHours(),
                    'd': gDate.getDate(),
                    'm': gDate.getMonth() + 1,
                    'y': gDate.getFullYear(),
                }

                // Apply format and add leading zeroes
                return format.replace(/([SMHdmy])/g, function (key) { return (mDate[key] < 10 ? '0' : '') + mDate[key]; });

                return getDate(str);
            };
        })(jQuery);

        function displayDateTime() {
            const datetimeDisplayElement = document.getElementById("hariwaktu");

            // Create a new Date object
            const currentDateTime = new Date();

            // Extract the date and time components
            const date = currentDateTime.toLocaleString();
            //const date = currentDateTime.toDateString();
            //const time = currentDateTime.toLocaleTimeString();
            var date1 = date.split(" ");
            var time = date1[1];
            var date2 = date1[0];

            // Display the date and time in the span element
            //datetimeDisplayElement.textContent = '${date}' ;
            document.getElementById("hariwaktu").innerHTML = date;
            // | Current Time: ${time}`;  
        }

        function displayDateTime2() {
            //document.getElementById("hariwaktu").innerHTML= $.format.date(new date(), "dd MMM yyyy HH:mm:ss");
            //document.getElementById("hariwaktu").innerHTML=  Date.parse(new Date()).toString('yyyy-MM-dd H:i:s')
            //const currentDateTime = new Date();
            //$('#hariwaktu').text(Date.parse("Jun 18, 2017 7:00:00 PM").toString('yyyy-MM-dd H:i:s'));
            //$('#hariwaktu').html($().getDate("H:M:S, m/d/y"))
            $('#hariwaktu').html($().getDate("d-m-y H:M:S"))
        }
        displayDateTime2();

        // Update the display every second using setInterval
        setInterval(displayDateTime2, 1000);   
        
/*
        var WindowsSize=function(){
    	var h=$(window).height(),
    		w=$(window).width();
    	$("#winSize").html("<p>Width: "+w+"<br>Height:"+h+"</p>");
        };
*/
        $("#maxwidth").html("<small> Width: "+$(window).width()+"</small>");
        
        $(window).on("resize", function() {
            $("#maxwidth").html("<small> Width: "+$(window).width()+"</small>");
        });
        //document.getElementById("maxwidth").innerHTML = date;
    </script>
</body>

</html>