<?php
if (!defined('SECURE_ACCESS')) {
    die('Direct access not permitted');
}
?>

<head>
    <style>
        .description {
            color: #040808ff;
            margin-bottom: 5px;
            font-size: 1.1rem;
            line-height: 1.0;
        }

        .upload-container {
            border: 2px dashed #3498db;
            border-radius: 10px;
            padding: 5px 5px;
            margin-bottom: 5px;
            transition: all 0.3s;
            background: #f8f9fa;
        }

        .upload-container:hover {
            background: #e8f4ff;
            border-color: #2980b9;
        }

        .upload-icon {
            font-size: 60px;
            color: #3498db;
            margin-bottom: 5px;
        }

        .upload-text {
            margin-bottom: 5px;
            color: #34495e;
        }

        .file-input {
            display: none;
        }

        .file-label {
            background: #3498db;
            color: white;
            padding: 12px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            display: inline-block;
            transition: background 0.3s;
        }

        .file-label:hover {
            background: #2980b9;
        }

        .selected-file {
            margin-top: 5px;
            font-weight: 200;
            color: #2c3e50;
        }

        .import-btn {
            background: #27ae60;
            color: white;
            border: none;
            padding: 7px 14px;
            font-size: 1rem;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 200;
            transition: background 0.3s;
            margin-top: 5px;
            margin-bottom: 5px;
        }

        .import-btn:hover {
            background: #219653;
        }

        .import-btn:disabled {
            background: #95a5a6;
            cursor: not-allowed;
        }

        .progress-container {
            margin: 10px 0;
            display: none;
        }

        .progress-bar {
            height: 20px;
            background: #ecf0f1;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 5px;
        }

        .progress {
            height: 100%;
            background: linear-gradient(90deg, #2ecc71, #1abc9c);
            width: 0%;
            transition: width 0.5s;
        }

        .progress-text {
            font-weight: 200;
            color: #2c3e50;
        }

        .result-container {
            display: none;
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 5px;
            border-radius: 8px;
            background: #f8f9fa;
        }

        .success {
            color: #27ae60;
            border: 1px solid #27ae60;
        }

        .error {
            color: #e74c3c;
            border: 1px solid #e74c3c;
        }

        .instructions {
            background: #f8f9fa;
            border-left: 4px solid #3498db;
            padding: 5px;
            margin: 10px 0;
            text-align: left;
            border-radius: 4px;
        }

        .instructions h3 {
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .instructions ol {
            padding-left: 20px;
            color: #34495e;
        }

        .instructions li {
            margin-bottom: 10px;
            line-height: 1.0;
        }

        .sample-table {
            width: 60%;
            border-collapse: collapse;
            margin: 10px 0;
        }

        .sample-table th,
        .sample-table td {
            border: 1px solid #ddd;
            padding: 5px;
            text-align: left;
        }

        .sample-table th {
            background-color: #f2f2f2;
        }

        .footer {
            margin-top: 5px;
            color: #7f8c8d;
            font-size: 0.9rem;
        }
    </style>
</head>

<body>
    <div class="modal fade" id="mdl-form-detail" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="mdl-label" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="container">
                    <!-- <h1><i class="fas fa-file-excel"></i> Excel to MySQL Data Importer</h1> -->
                    <p class="description"></p>
                    <div class="instructions">
                        <h5><i class="fas fa-info-circle"></i> Cara import :</h5>
                        <ol>
                            <li>Siapkan terlebih dahulu file excel yang akan di-'import'</li>
                            <li>Klik "Pilih File Excel"</li>
                            <li>Klik "Import Data" untuk mulai proses import</li>
                            <li>Tunggu sampai proses import selesai dan lihat hasilnya</li>
                        </ol>

                        <h5>Contoh Format Excel :</h5>
                        <table class="sample-table">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Nomor Tag</th>                                    
                                    <th>Berat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Item A</td>
                                    <td>A01P0000001</td>                                    
                                    <td>28</td>
                                </tr>
                                <tr>
                                    <td>Item B</td>
                                    <td>B02M000002</td>                                    
                                    <td>32</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="upload-container">
                        <i class="fas fa-cloud-upload-alt upload-icon"></i>
                        <p class="upload-text">Select your Excel file to import</p>
                        <input type="file" id="fileInput" class="file-input" accept=".xlsx, .xls, .csv">
                        <label for="fileInput" class="file-label">
                            <i class="fas fa-file-excel"></i> Pilih File Excel
                        </label>
                        <p id="selectedFile" class="selected-file">No file selected</p>
                    </div>
                <div id="search-fields2">
                    <button id="importBtn" class="import-btn" disabled>
                        <i class="fas fa-database"></i> Import Data
                    </button>
                </div>
                    <div id="progressContainer" class="progress-container">
                        <div class="progress-bar">
                            <div id="progress" class="progress"></div>
                        </div>
                        <p id="progressText" class="progress-text">Processing: 0%</p>
                    </div>

                    <div id="resultContainer" class="result-container"></div>

                    <!-- <div class="footer">
                        <p>Note: This is a frontend demonstration. Backend implementation required for actual database import.</p>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const fileInput = document.getElementById('fileInput');
            const importBtn = document.getElementById('importBtn');
            const selectedFile = document.getElementById('selectedFile');
            const progressContainer = document.getElementById('progressContainer');
            const progress = document.getElementById('progress');
            const progressText = document.getElementById('progressText');
            const resultContainer = document.getElementById('resultContainer');
            var $gid_user = "<?php echo $_SESSION['id_user']; ?>";

            fileInput.addEventListener('change', function() {
                if (this.files.length > 0) {
                    selectedFile.textContent = `Selected file: ${this.files[0].name}`;
                    importBtn.disabled = false;
                } else {
                    selectedFile.textContent = 'No file selected';
                    importBtn.disabled = true;
                }
            });

            importBtn.addEventListener('click', function() {
                const formData = new FormData();
                formData.append('excel_file', fileInput.files[0]);
                formData.append('g_user', $gid_user);
                
                const date1 = document.getElementById('tgltag2');
                var date2 =new Date(date1.value);
                var date3=[date2.getFullYear(),date2.getMonth()+1,date2.getDate()].join('-')
                //console.log(date3);
                formData.append('tgltag', date3);
                // Simulate import process
                progressContainer.style.display = 'block';
                resultContainer.style.display = 'none';

                const xhr = new XMLHttpRequest();
                
                // Track upload progress
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percentComplete = (e.loaded / e.total) * 50; // First 50% for upload
                        progress.style.width = percentComplete + '%';
                        progressText.textContent = `Uploading: ${Math.round(percentComplete)}%`;
                    }
                });
                
                // Track download progress (simulated for processing)
                xhr.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percentComplete = 50 + (e.loaded / e.total) * 50; // Second 50% for processing
                        progress.style.width = percentComplete + '%';
                        progressText.textContent = `Processing: ${Math.round(percentComplete)}%`;
                    }
                });
                
                xhr.open('POST', './query/import.php', true);
                
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            
                            if (response.status === 'success') {
                                resultContainer.className = 'result-container success';
                                resultContainer.innerHTML = `
                                    <h3><i class="fas fa-check-circle"></i> Import Successful!</h3>
                                    <p>${response.inserted_rows} records imported from ${fileInput.files[0].name}</p>
                                `;
                            } else {
                                resultContainer.className = 'result-container error';
                                resultContainer.innerHTML = `
                                    <h3><i class="fas fa-exclamation-circle"></i> Import Failed</h3>
                                    <p>Error: ${response.message}</p>
                                `;
                            }
                        } catch (e) {
                            resultContainer.className = 'result-container error';
                            resultContainer.innerHTML = `
                                <h3><i class="fas fa-exclamation-circle"></i> Error</h3>
                                <p>Invalid response from server: ${xhr.responseText}</p>
                            `;
                        }
                    } else {
                        resultContainer.className = 'result-container error';
                        resultContainer.innerHTML = `
                            <h3><i class="fas fa-exclamation-circle"></i> Server Error</h3>
                            <p>Error ${xhr.status}: ${xhr.statusText}</p>
                        `;
                    }
                    
                    resultContainer.style.display = 'block';
                    progress.style.width = '100%';
                    progressText.textContent = 'Complete: 100%';
                    
                    // Reset button and file input after a delay
                    setTimeout(() => {
                        importBtn.disabled = true;
                        fileInput.value = '';
                        selectedFile.textContent = 'No file selected';
                    }, 2000);
                };
                
                xhr.onerror = function() {
                    resultContainer.className = 'result-container error';
                    resultContainer.innerHTML = `
                        <h3><i class="fas fa-exclamation-circle"></i> Network Error</h3>
                        <p>Unable to connect to the server. Please try again.</p>
                    `;
                    resultContainer.style.display = 'block';
                };
                
                xhr.send(formData);
           });

        });
        const searchFieldsContainer2 = document.getElementById('search-fields2');
        createDateRangeInput2(0); // Assuming date is in the first column (index 0   )

        function createDateRangeInput2(index) {
            const container2 = document.createElement('div');
            container2.className = 'date-range-container';
            container2.style.display = 'inline-block';

            const fromLabel2 = document.createElement('span');
                fromLabel2.textContent = 'Tgl Tag : ';
                container2.appendChild(fromLabel2);
                fromLabel2.style.marginleft = '5px';

            const fromInput2 = document.createElement('input');
            fromInput2.type = 'date';
            //fromInput2.className = 'search-input date-range-input';
            fromInput2.id = 'tgltag2';
            //fromInput2.placeholder = 'Tgl Tag';
            //fromInput2.dataset.columnIndex = index;
            //fromInput2.dataset.rangeType = 'from';
            fromInput2.min = '2025-08-31';
            container2.appendChild(fromInput2);

            const today2 = new Date();

            fromInput2.valueAsDate = new Date(today2.getFullYear(), today2.getMonth(), 2);
            // Add event listeners
            searchFieldsContainer2.appendChild(container2);
        }
    </script>
</body>

</html>