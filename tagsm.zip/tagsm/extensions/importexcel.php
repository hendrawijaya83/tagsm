<?php
if (!defined('SECURE_ACCESS')) {
    die('Direct access not permitted');
}
?>
<div class="modal fade" id="mdl-form-detail" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="mdl-label" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="upload-container">
            <i class="fas fa-cloud-upload-alt upload-icon"></i>
            <p class="upload-text">Select your Excel file to import</p>
            
            <input type="file" id="fileInput" class="file-input" accept=".xlsx, .xls, .csv">
            <label for="fileInput" class="file-label">
                <i class="fas fa-file-excel"></i> Choose Excel File
            </label>
            
            <p id="selectedFile" class="selected-file">No file selected</p>
        </div>
        
        <button id="importBtn" class="import-btn" disabled>
            <i class="fas fa-database"></i> Import Data
        </button>
        
        <div id="progressContainer" class="progress-container">
            <div class="progress-bar">
                <div id="progress" class="progress"></div>
            </div>
            <p id="progressText" class="progress-text">Processing: 0%</p>
        </div>
        
        <div id="resultContainer" class="result-container"></div>
        </div>
    </div>
</div>
