# Copyright (c) 2023 - Pustaka Koding - Indra Styawantoro. All rights reserved.


# Permissions

- Private use
- Modification
- Distribution


# Limitations

- Commercial use
- Liability
- Warranty
