<?php
// pengecekan ajax request untuk mencegah direct access file, agar file tidak bisa diakses secara langsung dari browser
// jika ada ajax request
//if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') && (isset($_POST['startDate']) && isset($_POST['endDate']))) {
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) {
    // nama tabel
    //$table = 'tblprod a inner join tblcat b on a.fk_catid=b.catid';
    $table = 'vwtblplan';
    // primary key tabel
    $primaryKey = 'noplan';

    // membuat array untuk menampilkan isi tabel.
    // Parameter 'db' mewakili nama kolom dalam database.
    // parameter 'dt' mewakili pengenal kolom pada DataTable.
    $columns = array(
        array( 'db' => 'kodemesin', 'dt' => 1 ),
        array( 'db' => 'namaitem', 'dt' => 2 ),
        array( 'db' => 'target', 'dt' => 3 ),
        array( 'db' => 'selesai', 'dt' => 4 ),
        array( 'db' => 'tgldeadline', 'dt' => 5, 'formatter' => function ($d, $row) {
                return date('d-m-Y', strtotime($d));
            }),
        array( 'db' => 'nonaktif', 'dt' => 6 ),
        array( 'db' => 'custname', 'dt' => 7 ),
        array( 'db' => 'kapmesin', 'dt' => 8 ),
        array( 'db' => 'noplan', 'dt' => 9 ),
    );
//echo "berhasil";
    // memanggil file "database.php" untuk informasi koneksi ke server SQL
    require_once "config/database.php";
    // memanggil file "ssp.class.php" untuk menjalankan datatables server-side processing
    require 'config/ssp.class.php';
    $date1=$_GET['startDate'];
    $date2=$_GET['endDate'];
        
    //$fk_prodid=3; //intval($_GET['fk_prodid']);
    $where = " tgldeadline >= '{$date1}' and tgldeadline <= '{$date2}'";
    //$where2 = " where d.fk_prodid = {$fk_prodid} ";
    //$wherebef = " tgl <= {$date1} ";
    //echo $date1;
    //$where=" siid=105105";
    //$where=" siid=".$siid;
    echo json_encode(
        //SSP::simple($_GET, $sql_details, $table, $primaryKey, $columns)
        SSP::complex($_GET, $sql_details, $table, $primaryKey, $columns,$where)
    );
}
// jika tidak ada ajax request
else {
    // alihkan ke halaman index
    session_start();
    session_destroy();
    header('location: index.php');
}
