<?php
// deklarasi parameter koneksi database
$sql_details = array(
    'user' => 'root',                               // username database, default “root”
    'pass' => 'rasengan',                                   // password database, default kosong
    'db'   => 'dbtagsm',                // nama database yang akan digunakan
    'host' => 'localhost'                           // server database, default “localhost” atau “127.0.0.1”
);
